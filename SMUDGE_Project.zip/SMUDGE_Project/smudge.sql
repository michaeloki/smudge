-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2017 at 11:49 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.5.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smudge`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(85) NOT NULL,
  `passwd` varchar(150) NOT NULL,
  `token` varchar(150) NOT NULL,
  `fullName` text NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `loginDate` datetime NOT NULL,
  `logoutDate` datetime NOT NULL,
  `regDate` datetime NOT NULL,
  `ip` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `doB` varchar(60) NOT NULL,
  `profilePic` varchar(250) NOT NULL,
  `candCV` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Portal Users';

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `passwd`, `token`, `fullName`, `mobile`, `loginDate`, `logoutDate`, `regDate`, `ip`, `address`, `doB`, `profilePic`, `candCV`) VALUES
(4, 'mikeoki.oki@gmail.com', '$2y$10$MxAv0tPmsIsbChaMfc3.IuHGCeZJZ3Fnzzr1R9IvdgiUigbp4orS.', '2PIpBMIjO8e5!qnGMiaaj313lpFIl7qaZnpdZ', 'Michael Oki', '0833137477', '2017-07-10 11:49:12', '0000-00-00 00:00:00', '2017-07-09 16:17:24', '::1', '46, Van Riebeeck Avenue', '11/15/1995', 'http://localhost/apps/Smudge/api/menu/media/Nadal_celebrates.jpg', 'http://localhost/apps/Smudge/api/menu/media/APP_Cost_Details.pdf'),
(5, 'coutinho@gmail.com', '$2y$10$ctdXSe9D.r5LhtVCsl0XR.4w4SYC1C6/EA3oWBsnn/GH0Br/.VyDW', 'j9FwZhjYPPh0&Ul5YzqwU!wwv8PzjTdeuZnB!', 'phillipe Coutinho', '+447920201', '2017-07-09 22:44:41', '0000-00-00 00:00:00', '2017-07-09 22:28:43', '::1', '1, Andfield Road, L4, Liverpool, UK', '11/23/2016', 'nil', 'nil');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
